<?php $__env->startSection('title', 'Editar Hallazgos'); ?>
<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_capturista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
  <div class="row justify-content-center align-items-center p-4"  >
    <div class="col-md-10 p-2 " style=" background-color:white;min-height: 74vh  " >
        <div class="container  " >
            <div class="row">
                <div class="col-12 "  style=" height: 10vh">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                             <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <!-- Mensajes de éxito -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-10 " >
                    <h3 style="color: #B72223">Editar registro</h3>
                </div>
                <div class="col-2 " >

                    <a href="<?php echo e(route('capturista.hallazgos',$muestreo->id_muestreo)); ?>" class="btn btn-dark">
                        <i class="bi bi-arrow-left"></i> Regresar
                    </a>
                </div> 
            </div>
            <div class="row centrarh ">
                <div class="col-sm-12  mb-3 centrarh " >
                    <form id="residuosForm" method="POST" action="<?php echo e(route('capturista.hallazgos.update',$muestreo->id_muestreo)); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="row ">
                            <div class="col-sm-2 mb-3 " >
                                <label  class="form-label size15"># de muestreo:</label>
                                <input type="number" class="form-control"  name="Nmuestreo" placeholder="# muestreo" required value="<?php echo e($muestreo->num_muestreo); ?>">
                            </div>
                            <div class=" col-sm-2 mb-3 ">
                                <label  class="form-label ">Playa:</label>
                                <select class="form-select" aria-label="Default select example" name="playa"  required>
                                    <option  >Selecciona playa </option>
                                    <?php $__currentLoopData = $playas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($playa->id_playa); ?>" <?php echo e($playa->id_playa == $muestreo->fk_playa ? 'selected': ''); ?>><?php echo e($playa->nombre_playa); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class=" col-sm-2 mb-3 " >
                                <label  class="form-label">Fecha:</label>
                                <input type="date" class="form-control" id="date" name="date" placeholder="Fecha" required value="<?php echo e($muestreo->fecha); ?>">
                            </div>
                            <div class=" col-sm-2 mb-3 ">
                                <label  class="form-label">Día:</label>
                                <select class="form-select" aria-label="Default select example" name="dia"  required>
                                    <option  >Selecciona día</option>
                                    <option value="viernes" <?php echo e($muestreo->dia=='viernes'?'selected':''); ?>>viernes</option>
                                    <option value="sabado" <?php echo e($muestreo->dia=='sabado'?'selected':''); ?>>sabado</option>
                                    <option value="domingo" <?php echo e($muestreo->dia=='domingo'?'selected':''); ?>>domingo</option>
                                </select>
                            </div>
                            <div class=" col-sm-3 mb-3 ">
                                <label  class="form-label">Zona:</label>
                                <select class="form-select" aria-label="Default select example" name="zona"  required>
                                    <option value="Debajo pleamar" <?php echo e($muestreo->zona=='Debajo pleamar'?'selected':''); ?>>Debajo pleamar</option>
                                    <option value="Encima pleamar" <?php echo e($muestreo->zona=='Encima pleamar'?'selected':''); ?>>Encima pleamar</option>
                                    <option value="Encima de la pleamar, hasta estructura fija" <?php echo e($muestreo->zona=='Encima de la pleamar, hasta estructura fija'?'selected':''); ?>>Encima de la pleamar, hasta estructura fija</option>
                                    <option value="Sobre y debajo de la pleamar" <?php echo e($muestreo->zona=='Sobre y debajo de la pleamar'?'selected':''); ?>>Sobre y debajo de la pleamar</option>
                                </select>
                            </div>
                        </div>
                        <div class="row centrarh ">
                            <div class="col-10 ">
                                <div class="row mb-3">
                                    <div class="col-md-5">
                                        <h5>Residuo</h5>
                                    </div>
                                    <div class="col-md-2">
                                        <h5>Cantidad</h5>
                                    </div>
                                    <div class="col-md-2">
                                        <h5>Porcentaje</h5>
                                    </div>
                                    <div class="col-md-3">
                                    </div> 
                                </div>
                                <?php
                                    $totalC=0
                                ?>
                                <?php $__currentLoopData = $hallazgos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hallazgo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-3 row1">
                                    <div class="col-md-5">
                                        <select name="hallazgosE[<?php echo e($hallazgo->id_hallazgo); ?>]" class="form-select" required>
                                            <option value="" disabled  >Selecciona un residuo </option>
                                            <?php $__currentLoopData = $residuos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $residuo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($residuo->id_tipo); ?>" <?php echo e($residuo->id_tipo == $hallazgo->fk_tipo ? 'selected': ''); ?>><?php echo e($residuo->nombre_tipo); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <input class="inputC form-control " type="number" name="cantidadesE[<?php echo e($hallazgo->id_hallazgo); ?>] " value="<?php echo e($hallazgo->cantidad); ?>" <?php echo e($totalC+=$hallazgo->cantidad); ?> min="0" onchange="updateTotals()" required>
                                    </div>
                                    <div class="col-md-2">
                                        <input class="inputC  form-control " type="text"   name="porcentajesE[<?php echo e($hallazgo->id_hallazgo); ?>]" value="<?php echo e($hallazgo->porcentaje); ?> %" min="0" onchange="updateTotals()" >
                                    </div>
                                    <div class="col-md-3">
                                    </div> 
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div id="residuosContainer">
                                
                                </div>
                                <div class="row mb-3 " style="border-top: 1px solid">
                                    <div class="col-md-5 mt-3">
                                        <p>Total:</p>
                                    </div>
                                    <div class="col-md-2 mt-3">
                                        <label class=" form-control" id="totalC"><?php echo e($totalC); ?></label>
                                    </div>
                                    <div class="col-md-2 mt-3">
                                        <label class=" form-control" id="totalP">0%</label>
                                    </div>
                                    <div class="col-md-3">
                                    </div>
                                </div>
                                <div class="">
                                    <button type="button" class="btn btn-danger" id="addMore" style="width: 200px" >Agregar más</button>
                                    <button type="submit" class="btn btn-secondary" style="width: 200px"> Guardar </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<script>
    window.residuos = <?php echo json_encode($residuos, 15, 512) ?>;
  </script>
<?php echo $__env->make('views_capturista.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\views_capturista\muestreos\update_hallazgos.blade.php ENDPATH**/ ?>
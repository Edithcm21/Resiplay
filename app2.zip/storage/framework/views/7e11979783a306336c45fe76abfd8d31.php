<?php $__env->startSection('title', 'Resultados'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_prueba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid " style="min-height: 80vh ; ">
    <div class="row justify-content-center align-items-center">
      <div class="filters col-sm-10 m-4">
        <h3 class="">Filtrar registros</h3>
        <form class="row " method="POST" action="<?php echo e(route('consulta.filtro')); ?>"  >
          <?php echo csrf_field(); ?>
          <div class="col-sm-2 m-1 p-1 ">
            <label for="playaSelect">Playa</label>
            <select  id="playaSelect" class="form-select" name="playa">
              <option value="0">Selecciona playa</option>
              <?php $__currentLoopData = $playas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($playa->id_playa); ?>"><?php echo e($playa->nombre_playa); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <option value="0">Todas</option>
            </select>
          </div>
          <div class="col-sm-2 m-1 p-1">
            <label for="clasificacionSelected">Clasificacion</label>
            <select id="clasificacionSelected"  class="form-select" name="clasificacion">
              <option value="0">Selecciona la clasifiación</option>
              <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($clasificacion->id_clasificacion); ?>"><?php echo e($clasificacion->nombre_clasificacion); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <option value="0">Todas</option>
            </select>
          </div>
          <div class="col-sm-2 m-1 p-1">
            <label for="muestreoSelected"># Muestreo</label>
            <select  id="muestreoSelected" class="form-select" name="muestreo">
              <option value="0">Selecciona muestreo</option>
              <?php $__currentLoopData = $num_muestreos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num_muestreo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($num_muestreo->num_muestreo); ?>"><?php echo e($num_muestreo->num_muestreo); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <option value="0">Todos</option>
            </select>
          </div>
          <div class="col-sm-3 m-1 p-1 ">
            <label for="zonaSelected">Zona</label><br>
            <select  id="zonaSelected" class="form-select" name="zona">
              <option value="0">Selecciona playa</option>
              <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($zona->zona); ?>"><?php echo e($zona->zona); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <option value="0">Todas</option>
            </select>
          </div>

          <div class="col-sm-2 m-1 p-1 " ><br>
            <button  type="submit" class=" btn-blue btn-largo" > Filtrar</button>
          </div>   
      </form>

      </div>
      <div class="col-sm-10 m-4 table-responsive">
    
        <?php
          $totales = array_fill(0, count($muestreos) * 2, 0);
        ?>
        <table class="table table-striped  table-hover border text-center">
          <thead>
            <tr class=" text-center border ">
              <th   style=" max-width: 30px ; " scope="col text-center border " class="col text-center border vertical-text" rowspan="5">Clasificacion</th>

              <th   style="min-width: 300px; max-width: 300px ; " scope="col text-center border " class="col text-center border" rowspan="5">Residuo</th>
            </tr>
            <tr class="border">
              <?php
                  // Agrupo por playa
                  $muestreosPorPlaya = $muestreos->groupBy('fk_playa');
              ?>
    
              <?php $__currentLoopData = $muestreosPorPlaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playaId => $muestreosDePlaya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      // Obtengo primero  el nombre de esa playa
                      $nombrePlaya = $muestreosDePlaya->first()->playa->nombre_playa;
                      $totalMuestreos = $muestreosDePlaya->count();
                  ?>
                  <th class="border text-center" colspan="<?php echo e($totalMuestreos * 2); ?>">
                     <p> Playa <?php echo e($nombrePlaya); ?></p> 
                  </th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
            
            <tr class="border">
              <?php $__currentLoopData = $muestreos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muestreo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th class="border " colspan="2">día: <?php echo e($muestreo->dia); ?><br> año: <?php echo e($muestreo->anio); ?>  <br>zona: <?php echo e($muestreo->zona); ?></th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr class="border">
              <?php $__currentLoopData = $muestreos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muestreo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th class="border" colspan="2"># de muestreo: <?php echo e($muestreo->num_muestreo); ?></th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr class="border">
              <?php $__currentLoopData = $muestreos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muestreo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td class="border">cantidad</td>
              <td class="border">porcentaje</td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $residuoFiltrado= $residuos->where('fk_clasificacion',$clasificacion->id_clasificacion);
              $totalResiduos = $residuoFiltrado->count();
              $contador = 0
            ?>
            <?php if($totalResiduos>0): ?>
            <tr >
              <td class="vertical-text" style="max-width: 20px" rowspan="<?php echo e($totalResiduos+1); ?>"><?php echo e($clasificacion->nombre_clasificacion); ?></td>
            </tr>
            <?php endif; ?>
            

            <?php $__currentLoopData = $residuoFiltrado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $residuo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Verifica si es la última fila de la clasificación
                $contador++; // Incrementa el contador en cada iteración
                $ultimaFila = ($contador == $totalResiduos);
               
            ?>
            <tr style="<?php echo e($ultimaFila ? 'border-bottom: 2px solid black;' : ''); ?>">
              <td class="text-start" style=" position: sticky; border-right: 2px solid black; min-width: 300px; max-width: 300px ; " ><?php echo e($residuo->nombre_tipo); ?></td>
                  
              
                <?php $__currentLoopData = $muestreos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $muestreo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                <?php
                // Busca el hallazgo
                $hallazgo = $hallazgos->firstWhere(function ($h) use ($muestreo, $residuo) {
                    return $h->id_muestreo == $muestreo->id_muestreo && $h->id_tipo == $residuo->id_tipo;
                });

    
                $cantidad = $hallazgo ? $hallazgo->cantidad : 0;
                $porcentaje = $hallazgo ? $hallazgo->porcentaje : 0;
    
                    // Actualizar los totales
                    $totales[$index * 2] += $cantidad;
                    $totales[$index * 2 + 1] += $porcentaje;
    
                ?>
                <?php if($hallazgo): ?>
                <td ><?php echo e($hallazgo->cantidad); ?></td>
                <td><?php echo e($hallazgo->porcentaje); ?>%</td>
                <?php else: ?>
                <td>--</td>
                <td>--</td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td>
              <td style="position: sticky;">Total</td>
              <?php $__currentLoopData = $totales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><strong><?php echo e($total); ?></strong></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          </tbody>
        </table>
      </div>
      
    
    </div>
  </div>
<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views/consultas.blade.php ENDPATH**/ ?>
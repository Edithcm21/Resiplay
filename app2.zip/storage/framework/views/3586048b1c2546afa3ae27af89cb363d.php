<?php $__env->startSection('title', '¿Quíenes somos?'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_prueba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="row container-fluid">

    <div class="col-sm-10   mx-auto  card-team" >
        <h2 class="team-title text-center"> ¿Quiénes somos?</h2>
        <p class="  p-5 pt-3 pb-1 ">Somos un equipo multidisciplinario liderado por Alethia Vázquez Morillas,
             profesora e investigadora de la Universidad Autónoma Metropolitana (UAM) y miembro del 
             Sistema Nacional de Investigadores (SNI). Nuestro trabajo se centra en el estudio y 
             desarrollo de soluciones innovadoras para el manejo y tratamiento de residuos, con un 
             enfoque especial en el impacto de los plásticos en los ecosistemas costeros.<br>
        </p>
        <p class="p-5 pb-0 pt-0">
            El equipo de trabajo está compuesto por colaboradores de diversas áreas académicas y 
            profesionales, pertenecientes al cuerpo académico de la UAM y otras instituciones afines. 
            Nos destacamos por integrar enfoques científicos y técnicos en áreas como:
        </p>
        <div class="p-5 pb-0 pt-0 m-4">
            <li ><strong>Investigación ambiental:</strong> Enfocada en la caracterización y mitigación de residuos en ecosistemas naturales.</li>
            <li><strong>Desarrollo sostenible:</strong> Implementación de estrategias para la gestión de residuos plásticos y materiales reciclables.</li>
            <li><strong>Divulgación científica:</strong> Promoción de conciencia ambiental mediante estudios, publicaciones y eventos educativos.</li>
      
        </div>
            
            
        <p class="p-5 pt-0">Trabajamos con el compromiso de generar conocimiento útil para comunidades locales y contribuir a la preservación de nuestros recursos naturales.</p>
         

         
    </div>
</div>
<br><br>
<div class="row mx-auto text-center">
    <div class="col-sm-10 mx-auto text-center ">
        <div class="row integrante-card p-2">
            <div class="col-md-4 text-center mb-5 ">
                <img src="<?php echo e(asset('images/alethia.jpg')); ?>" alt="Nombre del integrante" class="border">   
            </div>
            <div class="col-md-8 mb-5 text-center text-md-start ">
                <h2>Dra. Alethia Vázquez Morillas</h2>
                <p class="description">
                    Ing. Química por la UAM-Azcapotzalco, <br>
                    Maestra en C. en Integración de Procesos por la Universidad de Manchester, <br>
                    Dra. en Ciencias e Ingeniería Ambientales por la UAM-Azcapotzalco.<br>
                    Profesora-investigadora en el Departamento de Energía de la UAM-A, donde imparte asignaturas a nivel
                    licenciatura y posgrado en temas relacionados con la gestión de residuos.
                </p>
                
                <a class="mas" href="https://investigacion.uam.mx/index.php/component/catalogo_investigadores/investigador/48235">mostrar más</a><br>
                Correo:
                <a href="mailto:alethia@azc.uam.mx" class="email">alethia@azc.uam.mx</a><br>
            </div>
        </div>
        <div class="row integrante-card p-2">
            <div class="col-md-8 mb-5 text-center text-md-start ">
                <h2>Dra. Arely Areanely Cruz Salas</h2>
                <p class="description">
                    Ing. Ambiental por la por la UAM-Azcapotzalco (UAM-A), <br>
                    Maestra en Ciencias e Ingeniería Ambiental en la misma institución, <br>
                    Dra. en Ciencias por la Universidad Autónoma de Baja California (UABC) campus Mexicali.<br>
                    Actualmente es profesor temporal en la UAM-A, donde ha impartido diversas UEAs a nivel licenciatura.
                </p>
                
                <a class="mas" href="https://plasticosresiduosymicroplasticos.com/wp-content/uploads/2023/11/cv-arely-a.-cruz-salas.pdf">mostrar más</a><br>
                Correo:
                <a href="mailto:areanelyc@gmail.com" class="email">areanelyc@gmail.com</a><br>
            </div>
            <div class="col-md-4 text-center mb-5 integrante-card ">
                <img src="<?php echo e(asset('images/arely.jpg')); ?>" alt="Nombre del integrante" class="border"> 
            </div>
        </div>
        <div class="row integrante-card p-2">
            <div class="col-md-4 text-center mb-5 ">
                <img src="<?php echo e(asset('images/JuanCarlos.jpg')); ?>" alt="Nombre del integrante" class="border"> 
            </div>
            <div class="col-md-8 mb-5 text-center text-md-start ">
                <h2>Dr. Juan Carlos Alvarez Zeferino</h2>
                <p class="description">
                    Ing. Ambiental por la por la UAM-Azcapotzalco. (UAM-A), <br>
                    Maestro en Ciencias e Ingeniería Ambiental por la misma institución.<br>
                    Dr. en Ciencias por la Universidad Autónoma de Baja California.<br>
                    Docente en la Escuela Militar de Ingenieros
                    Docente la Universidad Autónoma Metropolitana - Azcapotzalco
                </p>
                
                <a class="mas" href="https://plasticosresiduosymicroplasticos.com/wp-content/uploads/2021/09/02082021-curriculum-vitae-jcaz-v17.pdf">mostrar más</a>
                <br>
                Correos:
                <a href="mailto:jucaf@correo.azc.uam.mx" class="email">jucaf@correo.azc.uam.mx </a>
                <a href="mailto:zeferinojuancarlos@gmail" class="email">; zeferinojuancarlos@gmail</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\Integrantes.blade.php ENDPATH**/ ?>
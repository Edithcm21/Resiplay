<h1>Articulos
</h1><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\views_capturista\articulos.blade.php ENDPATH**/ ?>
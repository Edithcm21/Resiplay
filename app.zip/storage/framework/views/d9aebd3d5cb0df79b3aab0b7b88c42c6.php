<?php $__env->startSection('title', 'Hallazgo'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
<div class="row justify-content-center align-items-center p-4"  >
    <div class="col-md-10 p-2 " style=" background-color:white;min-height: 74vh  " >
        <div class="container  " >
            <div class="row">
                <div class="col-12 "  style=" height: 10vh">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                             <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <!-- Mensajes de éxito -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row m-4"  >
                <div class="col-sm-5 mt-4"   >
                    <h3 style="color: #B72223">Playa <?php echo e($muestreo->playa->nombre_playa); ?></h3>   
                </div>
                <div class="col-sm-2  mt-4 "  >
                    <a href="/admin/hallazgos/edit/<?php echo e($muestreo->id_muestreo); ?>">
                        <button type="submit" class="btn  btn-secondary " style="width: 100%; ">Editar</button>
                    </a>
                </div> 
                <div class="col-sm-2-5 mt-4 "  >
                    <button class="btn  btn-danger " type="button" data-bs-toggle="modal" data-bs-target="#deleteModalHallazgos"  style="width: 100%; ">Eliminar Registro</button>
                   
                </div> 
                <div class="col-sm-2 mt-4" >
                    <a href="/admin/muestreos" class="btn btn-dark"  style="width: 100%; ">
                        <i class="bi bi-arrow-left"></i> Regresar
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="mb-3 col-sm-2">
                    <label for="numMuestreo" class=""># de muestreo :</label>
                    <input type="text" readonly class="form-control" id="numMuestreo" value="<?php echo e($muestreo->num_muestreo); ?>">
                </div>
                <div class="mb-3 col-sm-3">
                    <label for="zona" class="">Zona :</label>
                    <input type="text" readonly class="form-control" id="zona" value="<?php echo e($muestreo->zona); ?>">
                </div>
                <div class="mb-3 col-sm-2">
                    <label for="fecha" class="">Fecha :</label>
                    <input type="text" readonly class="form-control" id="fecha" value="<?php echo e($muestreo->fecha); ?>">
                </div>
                <div class="mb-3 col-sm-2">
                    <label for="dia" class="">Día :</label>
                    <input type="text" readonly class="form-control" id="dia" value="<?php echo e($muestreo->dia); ?>">
                </div>
                <div class="mb-3 mt-1 col-sm-3 ">
                    <input type="text" readonly class="form-control text-center alert <?php echo e($muestreo->autorizado == 1 ? 'alert-success' : 'alert-secondary'); ?>" id="autorizado" value="<?php echo e($autorizado); ?>" >
                </div>
            </div>
            <div class="row centrarh">
                <div class="col-sm-8 mt-4 table-responsive">
                    <table class="table table-striped  border">
                        <thead>
                            <tr >
                                <th>Clasificacion</th>
                                <th>Residuo</th>
                                <th>Cantidad</th>
                                <th>Porcentaje</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $totalC=0;
                                $totalP=0;
                            ?>
                            <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $hallazgosFiltrados = $hallazgos->where('id_clasificacion',$clasificacion->id_clasificacion);
                                $total=$hallazgosFiltrados->count();
                                $first = true; 
                                ?>
                                <?php if($total>0): ?>
                                    <?php $__currentLoopData = $hallazgosFiltrados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hallazgo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="">
                                        <?php if($first): ?>
                                            <td rowspan="<?php echo e($total); ?>"><?php echo e($clasificacion->nombre_clasificacion); ?> </td>
                                            <?php 
                                                $first = false; 
                                                
                                            ?> 
                                        <?php endif; ?>
                                        <?php
                                            $totalC +=$hallazgo->cantidad;
                                            $totalP +=$hallazgo->porcentaje;
                                        ?>
                                            <td><?php echo e($hallazgo->nombre_tipo); ?></td>
                                            <td><?php echo e($hallazgo->cantidad); ?></td>
                                            <td><?php echo e($hallazgo->porcentaje); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                        <tfoot >
                            <tr >
                                <td></td>
                                <th>Total:</th>
                                <th><?php echo e($totalC); ?></th>
                                <th><?php echo e($totalP); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

 
 <div class="modal fade" id="deleteModalHallazgos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header" style="border: none">
          <h5 class="modal-title" id="exampleModalLabel">Se eliminarán todos los datos del muestreo </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <h6>¿Estas seguro de eliminar el registro?</h6>
          
        </div>
        
        <div class="modal-footer" style="border: none">
          <form id="formDelete"  action="<?php echo e(route('admin.hallazgos.delete',$muestreo->id_muestreo)); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            <button type="submit" class="btn btn-secondary btn-sm" >Eliminar</button>
          </form>
          <button type="submit" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Cancelar</button>
        </div>
      </div>
    </div>
  </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('views_admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_admin\muestreos\hallazgos.blade.php ENDPATH**/ ?>
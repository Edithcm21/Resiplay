<?php $__env->startSection('title', 'Editar perfil'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
    <div class="row justify-content-center align-items-center p-4"  >
        <div class="col-md-8 p-2 " style=" background-color:white;min-height: 73vh  " >
            <div class="container  " >
                <div class="row">
                    <div class="col-12 "  style=" height: 10vh">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                             <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?>
                        <!-- Mensajes de éxito -->
                        <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row"  >
                    <div class="col-sm-12 col-lg-12 mt-4"   >
                        <form class="row mb-3 justify-content-center align-items-center"method="POST" action="<?php echo e(route('perfil.update')); ?> " id="form_perfilEdit" >
                        <?php echo csrf_field(); ?>
                        <div class="col-sm-8">
                            <h3 style="color: #B72223">Editar perfil</h3>
                            <div class=" form-group mb-3" >
                                <label class="form-label"> Nombre completo:</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" required value="<?php echo e(Auth::user()->name); ?>">
                            </div>
                            <div class=" form-group mb-3"  >
                                <label class="form-label">Correo:</label>
                                <input type="email" class="form-control" id="correo" name="correo" placeholder="Correo electrónico"  required value="<?php echo e(Auth::user()->email); ?>">
                            </div>
                        
                            <div class="form-group mb-3">
                                <label for="password">Nueva Contraseña (opcional)</label>
                                <input type="password" class="form-control" id="password" name="password" minlength="8">
                            </div>
                    
                            <div class="form-group mb-3">
                                <label for="password_confirmation">Confirmar Contraseña</label>
                                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation"  minlength="8">
                                <small id="igual" class="text-danger" style="display:none;">Las contraseñas no coinciden.</small>
                            </div>
                                <button type="submit" class="btn  btn-secondary border" style="width: 100%">Guardar Cambios</button>
                         
                        </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('views_admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_admin\perfilEdit.blade.php ENDPATH**/ ?>
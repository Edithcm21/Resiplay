<?php $__env->startSection('title', 'Publicaciones'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_prueba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>

<div class="container-fluid p-5">
    <h1 class=" fw-bold">PUBLICACIONES</h1>
    <div class="row p-5  centrarh "  >
    <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-10 " style="border-bottom: 2px solid #ac0e28;  ">
        <div class=" mb-3  " style="">
            <div class="row g-0   pt-3">
              <div class="col-sm-3 col-4 my-auto mx-auto">
                <a href="<?php echo e(Storage::url($publicacion->file)); ?>">
                    <img src="<?php echo e(Storage::url($publicacion->img)); ?>" alt="" class="img-fluid border  rounded-start" style=" max-height:250px">
                </a>
              </div>
              <div class="col-md-9 col-8  p-4" >
                <a href="<?php echo e(Storage::url($publicacion->file)); ?>"  class="card-pdf">
                <div class="card-body ">
                    <h1 class="card-title text-red fw-bold"><?php echo e($publicacion->titulo); ?></h3>
                    <h3 class="card-text"><?php echo e($publicacion->descripcion); ?><br></h5>
                    <h6 class="card-text"><small >autores: <?php echo e($publicacion->autores); ?> <br> fecha: <?php echo e($publicacion->fecha); ?></small></h6>
                  
                </div>
              </a>
              </div>
            </div>
          </div>
    </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br><br><br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views/publicaciones.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Playas'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_capturista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
    <div class="row justify-content-center align-items-center p-4"  >
        <div class="col-md-10 p-2 " style=" background-color:white;min-height: 74vh  " >
            <div class="container  " >
                <div class="row">
                    <div class="col-12 "  style=" height: 10vh">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                             <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?>
                        <!-- Mensajes de éxito -->
                        <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row"  >
                    <div class="col-sm-12 col-lg-12 mt-4"   >
                        <h3 style="color: #B72223">Playas</h3>
                        <form class="row mb-3"method="POST" action="<?php echo e(route('capturista.Playas.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class=" col-sm-2 mb-3" >
                                <input type="text" class="form-control" id="nombre_playa" name="nombre_playa" placeholder="Nombre" required maxlength="25">
                            </div>
                            <div class=" col-sm-2 mb-3"  >
                                <input type="text" class="form-control" id="latitud" name="latitud" placeholder="latitud"  required minlength="10" maxlength="10">
                            </div>
                            <div class=" col-sm-2 mb-3" >
                                <input type="text" class="form-control" id="longitud" name="longitud" placeholder="longitud"  required  minlength="10" maxlength="10">
                            </div>
                            <div class=" col-sm-2 mb-3 ">
                                <select class="form-select" aria-label="Default select example" name="municipio"  >
                                    <option  >Municipio</option>
                                    <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($municipio->id_municipio); ?>"><?php echo e($municipio->nombre_municipio); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class=" col-sm-2 mb-3 ">
                                <select class="form-select" aria-label="Default select example" name="region">
                                    <option  >Region</option>
                                    <?php $__currentLoopData = $regiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region->id_region); ?>"><?php echo e($region->nombre_region); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-sm-2 mb-3 " >
                                <button type="submit" class="btn btn-secondary btn-sm">Agregar</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mt-4 table-responsive">
                        <table class="table table-striped ">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Playa</th>
                                    <th>Region</th>
                                    <th>Municipio</th>
                                    <th>Latitud</th>
                                    <th>Longitud</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $playas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($playa->id_playa); ?></td>
                                    <td><?php echo e($playa->nombre_playa); ?></td>
                                    <td><?php echo e($playa->region->nombre_region); ?></td>
                                    <td><?php echo e($playa->municipio->nombre_municipio); ?></td>
                                    <td><?php echo e($playa->latitud); ?></td>
                                    <td><?php echo e($playa->longitud); ?></td>
                                    <td>
                                        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($playa->id_playa); ?>" data-bs-id="<?php echo e($playa->id_playa); ?>">Editar</button>
                                        <!-- Modal Edit -->
                                        <div class="modal fade" id="editModal<?php echo e($playa->id_playa); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Editar Playa</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form class=" mb-3 "method="POST" action="<?php echo e(route('capturista.Playas.update',$playa->id_playa)); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                            <div class="mb-3">
                                                                <label  class="form-label">Nombre</label>
                                                                <input type="text" class="form-control"  name="modalNombre_playa" placeholder="Nombre" required value="<?php echo e($playa->nombre_playa); ?>">
                                                            </div>
                                                            <div class="mb-3 ">
                                                                <label for="modalLatitud" class="form-label">Latitud</label>
                                                                <input type="text" class="form-control"  name="modalLatitud" placeholder="Latitud"  required value="<?php echo e($playa->latitud); ?>">
                                                            </div>
                                                            <div class="mb-3 ">
                                                                <label for="modalLongitud" class="form-label">Longitud</label> 
                                                                <input type="text" class="form-control" name="modalLongitud" id="modalLongitud" placeholder="Longitud" value="<?php echo e($playa->longitud); ?>">
                                                            </div>
                                                            <div class="mb-3 ">
                                                                <label for="modalMunicipio" class="form-label">Municipio</label>
                                                                <select  class="form-control " name="modalMunicipio"   required>
                                                                    <option value="<?php echo e($playa->municipio->id_municipio); ?>" selected><?php echo e($playa->municipio->nombre_municipio); ?></option>
                                                                    <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($municipio->id_municipio); ?>"><?php echo e($municipio->nombre_municipio); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 ">
                                                                <label for="modalRegion" class="form-label">Region</label>
                                                                <select  class="form-control " name="modalRegion"  >
                                                                    <option value="<?php echo e($playa->region->id_region); ?>" selected><?php echo e($playa->region->nombre_region); ?></option>
                                                                    <?php $__currentLoopData = $regiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($region->id_region); ?>"><?php echo e($region->nombre_region); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-danger btn-sm"> Actualizar </button>
                                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


    

<?php echo $__env->make('views_capturista.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_capturista\playas.blade.php ENDPATH**/ ?>
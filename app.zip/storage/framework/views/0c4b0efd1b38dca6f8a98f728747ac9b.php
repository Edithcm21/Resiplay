<?php $__env->startSection('title', 'Residuos'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
    <div class="row justify-content-center align-items-center p-4"  >
        <div class="col-md-12 p-2 " style=" background-color:white;min-height: 72vh  " >
            <div class="container  " >
                <div class="row">
                    <div class="col-md-4 " >
                        <h2 style="color: #B72223" class="m-2 aling-center">Residuos</h2>
                        <div class="row" >
                            <div class="col-sm-12 col-lg-12 mt-4 card"   >
                                <form class="row mb-4"method="POST" action="<?php echo e(route('admin.Tipo_residuos.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class=" col-sm-12 mb-3 pt-4">
                                        <input type="text" class="form-control" id="nombre_tipo" name="nombre_tipo" placeholder="Residuo" maxlength="100" required>
                                    </div>
                                    <div class=" col-sm-12 mb-4 pt-4">
                                        <select class="form-select" aria-label="Default select example" name="fk_clasificacion" required>
                                        <option value="" selected>Selecciona clasificación</option>
                                        <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($clasificacion->id_clasificacion); ?>"><?php echo e($clasificacion->nombre_clasificacion); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-12 col-8 pt-4" >
                                        <button type="submit" class="btn btn-secondary btn-sm">Agregar</button>  
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row"  style=" height: 10% ">
                            <div class="col-sm-12 col-lg-12 mt-4"   >
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                                    <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- Mensajes de éxito -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">

                    </div>
                    <div class="col-md-7  p-2">
                        <div class="row">
                            <div class="col-12  table-responsive card"style="max-height: 65vh" >
                                <table class="table table-striped size12" >
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Residuo</th>
                                            <th>Clasificacion</th>
                                            <th >Editar</th>
                                            <th >Eliminar</th>
                                        </tr>
                                    </thead>
                                    <tbody class="">
                                        <?php $__currentLoopData = $tipo_residuos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_residuo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="">
                                            <td class=""><?php echo e($tipo_residuo->id_tipo); ?></td>
                                            <td class=""><?php echo e($tipo_residuo->nombre_tipo); ?></td>
                                            <td class=""><?php echo e($tipo_residuo->clasificacion->nombre_clasificacion); ?></td>
                                            <td class=" border  ">
                                                <button class="btn btn-secondary btn-sm size12" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($tipo_residuo->id_tipo); ?>" data-bs-id="<?php echo e($tipo_residuo->id_tipo); ?>">Editar</button>
                                                <!-- Modal Edit -->
                                                <div class="modal fade" id="editModal<?php echo e($tipo_residuo->id_tipo); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" style="color: #B72223" id="exampleModalLabel">Editar tipo de residuo</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form class=" mb-3 "method="POST" action="<?php echo e(route('admin.Tipo_residuos.update',$tipo_residuo->id_tipo)); ?>">
                                                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                                    <div class="mb-3">
                                                                        <label  class="form-label">Tipo de residuo</label>
                                                                        <input type="text" class="form-control"  name="modalTipo_residuo" placeholder="tipo de residuo" required value="<?php echo e($tipo_residuo->nombre_tipo); ?> " maxlength="100">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label  class="form-label">Clasificacion</label>
                                                                        <select class="form-select" aria-label="Default select example" name="modalFk_clasificacion">
                                                                            <option value="<?php echo e($tipo_residuo->clasificacion->id_clasificacion); ?>" selected><?php echo e($tipo_residuo->clasificacion->nombre_clasificacion); ?></option>
                                                                            <?php $__currentLoopData = $clasificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clasificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($clasificacion->id_clasificacion); ?>"><?php echo e($clasificacion->nombre_clasificacion); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="mb-3 text-end">
                                                                        <button type="submit" class="btn btn-danger btn-largo "> Actualizar </button>
                                                                        <button type="button" class="btn btn-secondary btn-largo " data-bs-dismiss="modal">Cancelar</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><button class="btn btn-danger size12  btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal" data-bs-id="<?php echo e($tipo_residuo->id_tipo); ?>">Eliminar</button> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header" style="border: none">
                    <h5 class="modal-title" id="exampleModalLabel">New message</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6>¿Estas seguro de eliminar el registro?</h6>
          
                </div>
        
                <div class="modal-footer" style="border: none">
                    <form id="formDelete"  data-action="<?php echo e(route('admin.Tipo_residuos.delete',1)); ?>" method="POST">
                        <?php echo csrf_field(); ?> 
                        <button type="submit" class="btn btn-secondary btn-sm" >Eliminar</button>
                    </form>
                    <button type="submit" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('views_admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\views_admin\residuos.blade.php ENDPATH**/ ?>
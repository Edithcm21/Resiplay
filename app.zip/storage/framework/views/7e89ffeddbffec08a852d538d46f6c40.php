<?php $__env->startSection('title', 'Publicaciones'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_capturista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
<div class="row justify-content-center align-items-center p-4"  >
    <div class="col-md-10 p-2 " style=" background-color:white; " >
        <div class="container  " >
            <div class="row">
                <div class="col-12 "  style=" height: 10vh">
                    <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                         <?php echo e(session('error')); ?>

                    </div>
                    <?php endif; ?>
                    <!-- Mensajes de éxito -->
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row"  >
                <div class="col-sm-12 col-lg-12 mt-4"   >
                    <h3 style="color: #B72223">Nuevo registro</h3>
                    <form class=" mb-3"method="POST" action="<?php echo e(route('capturista.publicaciones.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class=" col-sm-4 mb-3" >
                            <label class="label-control">Título dela publicaión</label>
                            <textarea class="form-control" id="titulo" name="titulo" placeholder="Título de la publicación" required maxlength="100"></textarea>
                        </div>
                        <div class=" col-sm-6 mb-3"  >
                            <label class="label-control">Descripción</label>
                            <textarea class="form-control" placeholder="Descripción" id="descripcion" name="descripcion" maxlength="500" required></textarea>
                            
                        </div>
                        <div class=" col-sm-2 mb-3" >
                            <label class="label-control">Fecha de publicación</label>
                            <input type="date" class="form-control mt-2" id="fecha" name="fecha" placeholder="Fecha de publicacion"  required>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col-sm-3 mb-3" >
                            <label class="label-control">Autores</label>
                            <textarea  class="form-control" id="autores" name="autores" placeholder="autores"  required  maxlength="100"></textarea>
                        </div>
                        
                        <div class="col-sm-3 mt-3 ">
                            <label for="archivo" class="form-label">Archivo pdf*</label> 
                            <input type="file" class="form-control m-0" name="archivo" id="archivo" accept="application/pdf"  required>
                        </div>
                        <div class="col-sm-3 mt-3 ">
                            <label for="portada" class="form-label">Portada (imagen)</label> 
                            <input type="file" class="form-control m-0" name="portada" id="portada" accept="image/png, image/jpeg, image/jpg"  required>
                        </div>
                        <div class="col-sm-2 mt-4 " >
                            <div class="mb-4"></div>
                            <button type="submit" class="btn btn-secondary btn-sm" style="width: 90%">Agregar</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-10 p-2 mt-4" style=" background-color:white; " >
        <div class="row">
            <h3 style="color: #B72223">Publicaciones</h3>
            <div class="col-12 mt-4 table-responsive">
                <table class="table table-striped ">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Titulo</th>
                            <th>Descripcion</th>
                            <th>Autores</th>
                            <th>Fecha de publicación</th>
                            <th>Archivo</th>
                            <th>Portada</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                            <td ><?php echo e($publicacion->id); ?></td>
                            <td><?php echo e($publicacion->titulo); ?></td>
                            <td><?php echo e($publicacion->descripcion); ?></td>
                            <td><?php echo e($publicacion->autores); ?></td>
                            <td><?php echo e($publicacion->fecha); ?></td>
                            <td><a href="<?php echo e(Storage::url($publicacion->file)); ?>" class="btn btn-sm btn-dark" target="_blank" style="width: 100%">Ver</a></td>
                            
                            <td><img src="<?php echo e(Storage::url($publicacion->img)); ?>" alt="" style="max-width: 100px" class="img-fluid"></td>
                            <td>
                                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($publicacion->id); ?>" data-bs-id="<?php echo e($publicacion->id); ?>">Editar</button>
                                <!-- Modal Edit -->
                                <div class="modal fade" id="editModal<?php echo e($publicacion->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Editar datos </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form class=" mb-3 "method="POST" action="<?php echo e(route('capturista.publicaciones.update',$publicacion->id)); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label  class="form-label">Titulo </label>
                                                            <textarea  class="form-control"  name="modalTitulo"required  maxlength="100"><?php echo e($publicacion->titulo); ?></textarea>
                                                        </div>
                                                        <div class="mb-3 ">
                                                            <label for="modalDescripcion" class="form-label">Descripción</label>
                                                            <textarea  class="form-control"  name="modalDescripcion" required  maxlength="500"><?php echo e($publicacion->descripcion); ?></textarea>
                                                        </div>
                                                        <div class="mb-3 ">
                                                            <label for="modalAutores" class="form-label">autores</label> 
                                                            <textarea class="form-control" name="modalAutores" id="modalAutores"  required  maxlength="100"><?php echo e($publicacion->autores); ?></textarea>
                                                        </div>
                                                        <div class="mb-3 ">
                                                            <label for="modalFecha" class="form-label">Fecha de publicación</label> 
                                                            <input type="date" class="form-control" name="modalFecha" id="modalFecha"  value="<?php echo e($publicacion->fecha); ?>">
                                                        </div>
                                                        <div class="mb-3 ">
                                                            <label for="modalArchivo" class="form-label">Archivo (Dejar en blanco sino desea cambiarlo)</label> 
                                                            <input type="file" class="form-control" name="modalArchivo" id="modalArchivo" accept="application/pdf"  >
                                                        </div>
                                                        <div class="mb-3 ">
                                                            <label for="modalimg" class="form-label">Imagen (Dejar en blanco sino desea cambiarlo)</label> 
                                                            <input type="file" class="form-control" name="modalimg" id="modalimg" accept="image/png, image/jpeg, image/jpg"  >
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer  ">
                                                        <button type="submit" class="btn btn-danger btn-modal"> Actualizar </button>
                                                        <button type="button" class="btn btn-secondary btn-modal" data-bs-dismiss="modal">Cancelar</button>
                                                    </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
 
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


    

<?php echo $__env->make('views_capturista.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_capturista\publicaciones.blade.php ENDPATH**/ ?>
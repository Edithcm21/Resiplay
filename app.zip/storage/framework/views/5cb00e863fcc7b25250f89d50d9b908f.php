


<section id="banner">
  <img src="<?php echo e(asset('images/Banner.jpg')); ?>" style="width:100%" alt="Descripción de la imagen">
 
</section>
<div class="portada " >
  <div class="contenido" style=""></div> 
  <div class="curva  " style=" ">
    <img src="<?php echo e(asset('images/curva.svg')); ?>" alt="curva" >
  </div>
</div>

<br><br>
<div class=" container " style="box-shadow:0px 10px 10px rgba(0, 0, 0, 0.2);">
  <div class=" row">
    <div class="col-12 col-sm-7">
      <h1 class="text-rojo text-center mb-4 fs-1 h1">RESIPLAY</h1>
      <p class="fade-in-text fs-5  ">RESIPLAY (Residuos sólidos en playas), es un sistema de Información Geográfico (SIG) que integra una base de datos
        que gestiona los resultados de diversos muestreos realizados por investigadores 
        de la UAM Azcapotzalco, dedicados a monitorear la contaminación 
        por residuos sólidos en las playas mexicanas. A través de esta 
        herramienta, buscamos generar conciencia sobre la importancia de 
        preservar nuestros ecosistemas costeros y proporcionar información
         valiosa para su protección. Explora el mapa interactivo, revisa 
         los datos de muestreo y descubre cómo puedes contribuir a mantener
          nuestras playas limpias y saludables.
      </p>
    </div>
    <div class="col-12 col-sm-5 ">
      <img src="" >
      

      <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="<?php echo e(asset('images/Muestreo-tuxpan.png')); ?>" class="d-block w-100 imagen-con-sombra imagen-fade-in" alt="...">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('images/c4.png')); ?>" class="d-block w-100 imagen-con-sombra imagen-fade-in" alt="...">
          </div>
          <div class="carousel-item">
            <img src="<?php echo e(asset('images/c6.png')); ?>" class="d-block w-100 imagen-con-sombra imagen-fade-in" alt="...">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
    
  </div>
</div>
  


<?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views/content_info.blade.php ENDPATH**/ ?>
 

<?php $__env->startSection('title', 'Municipios'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_capturista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
<div class="row justify-content-center align-items-center p-4"  >
    <div class="col-md-12 p-2 " style=" background-color:white;min-height: 72vh  " >
        <div class="container  " >
            <div class="row">
                <div class="col-md-4 " >
                    <h2 style="color: #B72223" class="m-2 aling-center">Municipios</h2>
                    <div class="row" >
                        <div class="col-sm-12 col-lg-12 mt-4 card"   >
                            <form class="row mb-4"method="POST" action="<?php echo e(route('capturista.municipios.store')); ?>">
                            <?php echo csrf_field(); ?>
                                <div class=" col-sm-12 mb-3 pt-4">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Nombre de municipio" maxlength="23" required>
                                </div>
                                <div class=" col-sm-12 mb-4 pt-4">
                                    <select class="form-select" aria-label="Default select example" name="estado" required>
                                        <option value="" selected>Selecciona Estado</option>
                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($estado->id_estado); ?>"><?php echo e($estado->nombre_estado); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-sm-12 col-8 pt-4" >
                                  <button type="submit" class="btn btn-secondary btn-sm">Agregar</button>  
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row"  style=" height: 10% ">
                        <div class="col-sm-12 col-lg-12 mt-4"   >
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                            <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                            <!-- Mensajes de éxito -->
                            <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                              <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-1">

                </div>
                <div class="col-md-7  p-2">
                    <div class="row">
                        <div class="col-12  table-responsive card">
                            <table class="table table-striped ">
                                  <thead>
                                      <tr>
                                          <th>ID</th>
                                          <th>Municipio</th>
                                          <th>Estado</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                  <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                          <td><?php echo e($municipio->id_municipio); ?></td>
                                          <td><?php echo e($municipio->nombre_municipio); ?></td>
                                          <td><?php echo e($municipio->estado->nombre_estado); ?></td>
                                          <td>
                                              <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($municipio->id_municipio); ?>" data-bs-id="<?php echo e($municipio->id_municipio); ?>">Editar</button>
                                                <!-- Modal Edit -->
                                              <div class="modal fade" id="editModal<?php echo e($municipio->id_municipio); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" style="color: #B72223" id="exampleModalLabel">Editar Usuario</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form class=" mb-3 "method="POST" action="<?php echo e(route('capturista.municipios.update',$municipio->id_municipio)); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                            <div class="mb-3">
                                                                <label  class="form-label">Municipio</label>
                                                                <input type="text" class="form-control"  name="modalName" placeholder="Municipio" required value="<?php echo e($municipio->nombre_municipio); ?>">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label  class="form-label">Estado</label>
                                                                <select class="form-select" aria-label="Default select example" name="modalEstado">
                                                                    <option value="<?php echo e($municipio->estado->id_estado); ?>" selected><?php echo e($municipio->estado->nombre_estado); ?></option>
                                                                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($estado->id_estado); ?>"><?php echo e($estado->nombre_estado); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 text-end">
                                                                <button type="submit" class="btn btn-danger btn-largo "> Actualizar </button>
                                                                <button type="button" class="btn btn-secondary btn-largo " data-bs-dismiss="modal">Cancelar</button>
                                                            </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                              </div>
                                          </td>
                                      </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                  </tbody>
                            </table>
                            <div class="d-flex justify-content-center">
                                <?php echo e($municipios->links('pagination::bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


    

<?php echo $__env->make('views_capturista.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_capturista\municipios.blade.php ENDPATH**/ ?>
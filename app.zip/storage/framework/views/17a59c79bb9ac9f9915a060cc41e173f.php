<h1>Articulos
</h1><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_capturista\articulos.blade.php ENDPATH**/ ?>
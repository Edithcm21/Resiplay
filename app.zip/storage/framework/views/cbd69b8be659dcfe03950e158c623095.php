<?php $__env->startSection('title', 'Region Marina'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_capturista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content' ); ?>
  <div class="row justify-content-center align-items-center p-4"  >
    <div class="col-md-12 p-2 " style=" background-color:white;min-height: 72vh  " >
        <div class="container  " >
            <div class="row">
                <div class="col-md-4 " >
                    <h2 style="color: #B72223" class="m-2 aling-center">Regiones marinas </h2>
                    <div class="row" >
                      <div class="col-sm-12 col-lg-12 mt-4 card"   >
                            <form class="row mb-4"method="POST" action="<?php echo e(route('capturista.RegionMarina.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <h4 style="color: var(--negro)" class="m-2 aling-center">Agregar regiones marinas</h4>
                                <div class=" col-sm-12 mb-3 pt-4">
                                    <input type="text" class="form-control" id="nombre_region" name="nombre_region" placeholder="Nombre de la región" maxlength="20">
                                </div>
                                <div class="col-sm-12 col-8 pt-4" >
                                    <button type="submit" class="btn btn-secondary btn-sm">Agregar</button>  
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row"  style=" height: 10% ">
                        <div class="col-sm-12 col-lg-12 mt-4"   >
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show myAlert" role="alert" id="myAlert"> 
                                <?php echo e(session('error')); ?>

                            </div>
                             <?php endif; ?>
                            <!-- Mensajes de éxito -->
                            <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show myAlert" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-7 " >
                    <div class="row">
                        <div class="col-12  table-responsive card">
                            <table class="table table-striped ">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Region marina</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $regiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($region->id_region); ?></td>
                                        <td><?php echo e($region->nombre_region); ?></td>
                                        
                                        <td>
                                            <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($region->id_region); ?>" data-bs-id="<?php echo e($region->id_region); ?>">Editar</button>
                                                <!-- Modal Edit -->
                                            <div class="modal fade" id="editModal<?php echo e($region->id_region); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" style="color: #B72223" id="exampleModalLabel">Editar Region Marina</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form class=" mb-3 "method="POST" action="<?php echo e(route('capturista.RegionMarina.update',$region->id_region)); ?>">
                                                              <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                                              <div class="mb-3">
                                                                <label  class="form-label">Region Marina</label>
                                                                <input type="text" class="form-control"  name="modalRegion" placeholder="Region Marina" required value="<?php echo e($region->nombre_region); ?>">
                                                              </div>
                                                              
                                                              <div class="mb-3 text-end">
                                                                <button type="submit" class="btn btn-danger btn-largo "> Actualizar </button>
                                                                <button type="button" class="btn btn-secondary btn-largo " data-bs-dismiss="modal">Cancelar</button>
                                                              </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center">
                                <?php echo e($regiones->links('pagination::bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('views_capturista.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\OneDrive\Escritorio\Resiplay\Resiplay\resources\views\views_capturista\RegionMarina.blade.php ENDPATH**/ ?>
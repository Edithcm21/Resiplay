<?php $__env->startSection('title', 'Publicaciones'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_prueba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<br>

<div class="container-fluid ">
    <h1 class=" fw-bold">PUBLICACIONES</h1>
    <div class="row p-5 " >
    <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-3">
        <div class="card card-red">
            <div class="card-body">
                <h4 class="card-title"><?php echo e($publicacion->titulo); ?></h4>
                <p class="card-text"><?php echo e($publicacion->descripcion); ?><br>
                </p>
                <p>autores: <?php echo e($publicacion->autores); ?><br>
                    fecha: <?php echo e($publicacion->fecha); ?></p>
                    
                    <td><a href="<?php echo e(Storage::url($publicacion->file)); ?>" class="btn btn-sm btn-dark" target="_blank" style="width: 100%">Ver archivo</a></td>


            </div>
        </div>
    </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br><br><br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\publicaciones.blade.php ENDPATH**/ ?>
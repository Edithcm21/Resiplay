



<div class="portada " style="height: 125vh">
  <div class="" style="height: 92vh"></div> 
  <div class="curva container-fluid p-0 m-0 " style="height: 50vh">
    <img src="<?php echo e(asset('images/curva.svg')); ?>" alt="" style="min-height: 100%; width:100%">
  </div>
</div>
<br><br>
<div class=" container ">
  <div class=" row">
    <div class="col-12 col-sm-7">
      <h1 class="text-rojo text-center mb-4 fs-1 h1">Residuos Costeros</h1>
      <p class="fade-in-text fs-5  ">Es una  plataforma que presenta 
        los resultados de los muestreos realizados por investigadores 
        de la UAM Azcapotzalco, dedicados a monitorear la contaminación 
        por residuos sólidos en las playas mexicanas. A través de esta 
        herramienta, buscamos generar conciencia sobre la importancia de 
        preservar nuestros ecosistemas costeros y proporcionar información
         valiosa para su protección. Explora el mapa interactivo, revisa 
         los datos de muestreo y descubre cómo puedes contribuir a mantener
          nuestras playas limpias y saludables.
      </p>
    </div>
    <div class="col-12 col-sm-5 ">
      <img src="" >
      <img src="<?php echo e(asset('images/Muestreo-tuxpan.png')); ?>" style="width: 100%" alt="equipo de investigadores en muestreo Tuxpan, Ver" class="imagen-con-sombra imagen-fade-in">
    </div>
    
  </div>
</div>
  


<?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\content_info.blade.php ENDPATH**/ ?>
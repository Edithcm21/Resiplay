<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar_prueba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid p-0 m-0" >
    <?php echo $__env->make('content_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </div>
  <br><br><br>
  <div class="row p-0 m-0 justify-content-center  " style="background-color: #F0F3F4" >
    
    <div class="col-md-10 "  style="height: 100vh;">
      <h1 class="text-rojo text-center m-4 fs-1 h1">Resultados</h1>
   
      <?php echo $__env->make('content_mapa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    
    <br><br><br>
  </div>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EdithCM\Downloads\ProyectoFinalECM-main\resources\views\welcome.blade.php ENDPATH**/ ?>